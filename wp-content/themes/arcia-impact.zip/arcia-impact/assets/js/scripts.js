
jQuery(document).ready(function($){ 
  

  $('.menu-trigger').click(function() {
    $('.hamburger-menu-wrapper').addClass('isOpen');
  });

  $('.menu-close').click(function() {
    $('.hamburger-menu-wrapper').removeClass('isOpen');
  });





  
});   