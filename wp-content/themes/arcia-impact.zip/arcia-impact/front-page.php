<?php 
// Template Name: Homepage
get_header(); while(have_posts())  : the_post(); ?>

<main id="primary" class="site-main">

 




</main><!-- #main -->

<?php get_footer(); endwhile; ?>